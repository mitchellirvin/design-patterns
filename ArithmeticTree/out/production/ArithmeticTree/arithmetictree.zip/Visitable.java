/**
 * Created by Mitch on 10/20/2015.
 */
public interface Visitable {

    public void accept(Visitor v);
}
